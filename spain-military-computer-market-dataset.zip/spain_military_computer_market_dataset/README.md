# Spain Military Computer Market — Dataset & Report Extract

This repository contains a small dataset and extracted metadata for the **Spain Military Computer Market** (Next Move Strategy Consulting, Report code: AD3658, published 05-Nov-2025).

## What’s in this ZIP
- `metadata.json` — Structured metadata (title, publish date, market sizes, CAGR, source URL).
- `summary.txt` — Short paraphrased summary and key insights extracted from the report page.
- `toc.txt` — Partial table of contents and segmentation inferred from the report landing page.
- `companies.csv` — List of key players mentioned on the report page.
- `README.md` — This file.

## Purpose
The goal of this package is to provide a reproducible, small dataset for analysts who want to:
- Quickly ingest report metadata into analytics pipelines.
- Use the summary and TOC for content indexing and NLP experiments.
- Reference the list of companies for competitive analysis or entity linking.

## Source
The dataset was compiled from the public report landing page on Next Move Strategy Consulting:
https://www.nextmsc.com/report/spain-military-computer-market-ad3658

> Note: This repository contains only extracted metadata and public information from the landing page. It does NOT include the full report PDF or any paywalled content.

## License & Usage
Use this dataset for research, internal analysis, or as a starting point for building larger datasets. If you publish work using this dataset, please cite the original report and Next Move Strategy Consulting.

## How to use
1. Download the ZIP and unzip into your workspace.
2. `metadata.json` can be parsed directly by scripts (Python, R, etc.).
3. `companies.csv` can be used to join with other datasets or to seed entity recognition models.

## Contact
If you want an expanded extraction (tables, figure captions, or company profiles), tell me what you need and I’ll prepare an extended package.

